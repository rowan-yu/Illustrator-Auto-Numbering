@echo off
chcp 65001 >nul
title ClickLabel Uninstaller

echo ============================================
echo   ClickLabel Uninstaller
echo ============================================
echo.

:: --- Detect Illustrator ---
set "AI_FOUND="
for %%Y in (2025 2024 2023) do (
    if exist "C:\Program Files\Adobe\Adobe Illustrator %%Y\Presets" (
        set "AI_PATH=C:\Program Files\Adobe\Adobe Illustrator %%Y"
        set "AI_FOUND=1"
        echo [OK] Found Adobe Illustrator %%Y
        goto :found
    )
)

:notfound
if not defined AI_FOUND (
    set /p "AI_PATH=Enter your Illustrator install path: "
)

:found
echo.

:: --- Remove from Chinese folder ---
if exist "%AI_PATH%\Presets\zh_CN\脚本\ClickNumber_v2.jsx" (
    del "%AI_PATH%\Presets\zh_CN\脚本\ClickNumber_v2.jsx" 2>nul
    del "%AI_PATH%\Presets\zh_CN\脚本\ClickNumber_v2_EN.jsx" 2>nul
    del "%AI_PATH%\Presets\zh_CN\脚本\ClickLetter.jsx" 2>nul
    echo [OK] Removed scripts from zh_CN folder
)

:: --- Remove from English folder ---
if exist "%AI_PATH%\Presets\en_US\Scripts\ClickNumber_v2.jsx" (
    del "%AI_PATH%\Presets\en_US\Scripts\ClickNumber_v2.jsx" 2>nul
    del "%AI_PATH%\Presets\en_US\Scripts\ClickNumber_v2_EN.jsx" 2>nul
    del "%AI_PATH%\Presets\en_US\Scripts\ClickLetter.jsx" 2>nul
    echo [OK] Removed scripts from en_US folder
)

:: --- Remove from startup ---
set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
if exist "%STARTUP%\ClickNumber_Hotkey.ahk" (
    del "%STARTUP%\ClickNumber_Hotkey.ahk" 2>nul
    echo [OK] Removed ClickNumber_Hotkey from startup
)
if exist "%STARTUP%\ClickLetter_Hotkey.ahk" (
    del "%STARTUP%\ClickLetter_Hotkey.ahk" 2>nul
    echo [OK] Removed ClickLetter_Hotkey from startup
)

echo.
echo ============================================
echo   Uninstall Complete!
echo   Restart Illustrator to apply changes.
echo ============================================
echo.
pause
