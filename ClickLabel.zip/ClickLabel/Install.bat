@echo off
chcp 65001 >nul
title ClickLabel Installer for Adobe Illustrator

echo ============================================
echo   ClickLabel Installer
echo   Auto Numbering ^& Lettering for Illustrator
echo ============================================
echo.

:: --- Detect Illustrator install path ---
set "AI_FOUND="
set "AI_PATH="

:: Check common paths
for %%Y in (2025 2024 2023) do (
    if exist "C:\Program Files\Adobe\Adobe Illustrator %%Y\Presets" (
        set "AI_PATH=C:\Program Files\Adobe\Adobe Illustrator %%Y"
        set "AI_FOUND=1"
        echo [OK] Found Adobe Illustrator %%Y
        goto :found
    )
)

:notfound
if not defined AI_FOUND (
    echo [!] Could not auto-detect Illustrator installation.
    echo.
    set /p "AI_PATH=Please enter your Illustrator install path: "
    if not exist "%AI_PATH%\Presets" (
        echo [ERROR] Invalid path. Presets folder not found.
        echo         Example: C:\Program Files\Adobe\Adobe Illustrator 2025
        pause
        exit /b 1
    )
)

:found
echo.

:: --- Detect language folder ---
set "SCRIPT_DIR="

if exist "%AI_PATH%\Presets\zh_CN\脚本" (
    set "SCRIPT_DIR=%AI_PATH%\Presets\zh_CN\脚本"
    echo [OK] Detected Chinese version
    goto :install
)

if exist "%AI_PATH%\Presets\en_US\Scripts" (
    set "SCRIPT_DIR=%AI_PATH%\Presets\en_US\Scripts"
    echo [OK] Detected English version
    goto :install
)

if exist "%AI_PATH%\Presets\ja_JP\スクリプト" (
    set "SCRIPT_DIR=%AI_PATH%\Presets\ja_JP\スクリプト"
    echo [OK] Detected Japanese version
    goto :install
)

:: Fallback: let user choose
echo [!] Could not detect language folder.
echo.
echo    1. Chinese  (zh_CN)
echo    2. English  (en_US)
echo    3. Enter custom path
echo.
set /p "LANG_CHOICE=Choose [1/2/3]: "

if "%LANG_CHOICE%"=="1" set "SCRIPT_DIR=%AI_PATH%\Presets\zh_CN\脚本"
if "%LANG_CHOICE%"=="2" set "SCRIPT_DIR=%AI_PATH%\Presets\en_US\Scripts"
if "%LANG_CHOICE%"=="3" set /p "SCRIPT_DIR=Enter full scripts folder path: "

if not exist "%SCRIPT_DIR%" (
    echo Creating folder: %SCRIPT_DIR%
    mkdir "%SCRIPT_DIR%" 2>nul
)

:install
echo.
echo Installing to: %SCRIPT_DIR%
echo.

:: --- Copy JSX scripts ---
copy /Y "%~dp0scripts\ClickNumber_v2.jsx" "%SCRIPT_DIR%\" >nul 2>&1
if %errorlevel%==0 (echo [OK] ClickNumber_v2.jsx) else (echo [FAIL] ClickNumber_v2.jsx)

copy /Y "%~dp0scripts\ClickNumber_v2_EN.jsx" "%SCRIPT_DIR%\" >nul 2>&1
if %errorlevel%==0 (echo [OK] ClickNumber_v2_EN.jsx) else (echo [FAIL] ClickNumber_v2_EN.jsx)

copy /Y "%~dp0scripts\ClickLetter.jsx" "%SCRIPT_DIR%\" >nul 2>&1
if %errorlevel%==0 (echo [OK] ClickLetter.jsx) else (echo [FAIL] ClickLetter.jsx)

echo.

:: --- Update AHK script paths ---
echo Updating hotkey script paths...
set "AHK_DIR=%~dp0hotkeys"

:: Update ClickNumber hotkey
powershell -Command "(Get-Content '%AHK_DIR%\ClickNumber_Hotkey.ahk') -replace 'ScriptPath := \".*\"', 'ScriptPath := \"%SCRIPT_DIR:\=\\%\\ClickNumber_v2.jsx\"' | Set-Content '%AHK_DIR%\ClickNumber_Hotkey.ahk'" >nul 2>&1
if %errorlevel%==0 (echo [OK] ClickNumber_Hotkey.ahk path updated) else (echo [!] Please manually edit ClickNumber_Hotkey.ahk)

:: Update ClickLetter hotkey
powershell -Command "(Get-Content '%AHK_DIR%\ClickLetter_Hotkey.ahk') -replace 'ScriptPath := \".*\"', 'ScriptPath := \"%SCRIPT_DIR:\=\\%\\ClickLetter.jsx\"' | Set-Content '%AHK_DIR%\ClickLetter_Hotkey.ahk'" >nul 2>&1
if %errorlevel%==0 (echo [OK] ClickLetter_Hotkey.ahk path updated) else (echo [!] Please manually edit ClickLetter_Hotkey.ahk)

echo.

:: --- Optional: Copy AHK to startup ---
set /p "ADD_STARTUP=Add hotkeys to Windows startup? (y/n): "
if /i "%ADD_STARTUP%"=="y" (
    set "STARTUP=%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup"
    copy /Y "%AHK_DIR%\ClickNumber_Hotkey.ahk" "%STARTUP%\" >nul 2>&1
    copy /Y "%AHK_DIR%\ClickLetter_Hotkey.ahk" "%STARTUP%\" >nul 2>&1
    echo [OK] Hotkeys will auto-start on boot
) else (
    echo [OK] Skipped. You can run .ahk files manually from the hotkeys folder.
)

echo.
echo ============================================
echo   Installation Complete!
echo ============================================
echo.
echo   Next steps:
echo   1. Restart Illustrator
echo   2. Find scripts in: File ^> Scripts
echo   3. For hotkeys: F2 = Number, F3 = Letter
echo      (requires AutoHotkey v2)
echo.
echo   AutoHotkey download: https://www.autohotkey.com/
echo ============================================
echo.
pause
